                   Netscape Signing Tool (signtool)
                         1.3 Release Notes
               ========================================

See the file license.doc for licensing information.

Unlike earlier releases, this release will work correctly after some root
certificates expire toward the end of 1999.

Documentation is available online at:
    http://developer.iPlanet.com/docs/manuals/signedobj/signtool/index.htm

Problems or questions not covered by the online documentation can be
discussed in the DevEdge Security Newsgroup.

