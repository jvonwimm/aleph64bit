/*
 * $Id: fmh.h,v 1.1.1.1 1996/03/07 15:18:09 mclareni Exp $
 *
 * $Log: fmh.h,v $
 * Revision 1.1.1.1  1996/03/07 15:18:09  mclareni
 * Fatmen
 *
 */
#define MAXNAME 8
#define MAXJOBN 8 /* Was 16 */
#define MAXHOST 8
#define MAXINFO 8 /* Was 16 */
