void DoAttention(char *name){
#include <stdio.h>
/*  This routine just prints a remined about non-implemented features 
 *  Valery Fine 30.05.96  JINR/Dubna, Russia  (E-mail: fine@vxcern.cern.ch
 */
   printf("===========================================================\n");
   printf("Attention !!! %s is not implemented for Windows NT\n", name);
   printf("===========================================================\n");
}
