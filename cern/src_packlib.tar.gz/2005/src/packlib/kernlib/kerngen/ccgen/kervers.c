/*
 * $Id:
 *
 * $Log:
 */

/*
 *  Dummy C routine to distinguish cernlib 2002 from earlier releases
 *   in configure scripts with nm
 */

void v2002()
{    
}
