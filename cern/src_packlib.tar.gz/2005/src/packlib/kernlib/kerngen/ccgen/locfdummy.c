#include "kerngen/pilot.h"
#include "kerngen/fortranc.h"

#ifndef CERNLIB_LOCF_CHARACTER
#define CERNLIB_LOCF_CHARACTER
#endif

#include "locf.c"

#ifdef CERNLIB_LOCF_CHARACTER
#undef CERNLIB_LOCF_CHARACTER
#endif
