#if 0
* This pilot patch was created from kerngent.car patch _mibm
#endif
#if 0
*    For IBM 360
#endif
#ifndef CERNLIB__MNORM
#define CERNLIB__MNORM
#endif
#ifndef CERNLIB_QMIBM
#define CERNLIB_QMIBM
#endif
#ifndef CERNLIB_QEBCDIC
#define CERNLIB_QEBCDIC
#endif
#if 0
*               do not test VXINVB/C
#endif
#ifdef CERNLIB_TVXINV
#undef CERNLIB_TVXINV
#endif
