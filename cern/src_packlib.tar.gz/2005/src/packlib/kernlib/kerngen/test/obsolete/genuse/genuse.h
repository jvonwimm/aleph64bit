*
* $Id: genuse.h,v 1.1.1.1 1996/02/15 17:55:05 mclareni Exp $
*
* $Log: genuse.h,v $
* Revision 1.1.1.1  1996/02/15 17:55:05  mclareni
* Kernlib
*
*
*    Generation and usage of Must-Data (for ML check)
* This directory was created from kerngent.car patch genuse
+EXE,MICKY,D=MINIT,MVERIF,MVERII
