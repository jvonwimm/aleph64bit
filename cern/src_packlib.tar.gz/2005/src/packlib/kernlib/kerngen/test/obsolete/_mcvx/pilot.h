#if 0
* This pilot patch was created from kerngent.car patch _mcvx
#endif
#if 0
*    For Convex 64 bit
#endif
#ifndef CERNLIB__MICKY
#define CERNLIB__MICKY
#endif
#ifndef CERNLIB_QMCVX
#define CERNLIB_QMCVX
#endif
#ifndef CERNLIB_QMCV64
#define CERNLIB_QMCV64
#endif
#ifndef CERNLIB_QUNIX
#define CERNLIB_QUNIX
#endif
#ifndef CERNLIB_A8
#define CERNLIB_A8
#endif
#ifndef CERNLIB_B64
#define CERNLIB_B64
#endif
#if 0
*               do not test VXINVB/C
#endif
#ifdef CERNLIB_TVXINV
#undef CERNLIB_TVXINV
#endif
