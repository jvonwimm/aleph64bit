#if 0
* This pilot patch was created from kerngent.car patch _mcvy
#endif
#if 0
*    For Convex 32 bit
#endif
#ifndef CERNLIB__MNORM
#define CERNLIB__MNORM
#endif
#ifndef CERNLIB_QUNIX
#define CERNLIB_QUNIX
#endif
#ifndef CERNLIB_QMCVX
#define CERNLIB_QMCVX
#endif
#ifndef CERNLIB_QMCV32
#define CERNLIB_QMCV32
#endif
