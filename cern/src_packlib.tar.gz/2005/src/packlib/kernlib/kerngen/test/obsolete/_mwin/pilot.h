#if 0
* This pilot patch was created from kerngent.car patch _mwin
#endif
#if 0
*    For PC with Windows/NT
#endif
#ifndef CERNLIB__MNORM
#define CERNLIB__MNORM
#endif
#ifndef CERNLIB_QMDOS
#define CERNLIB_QMDOS
#endif
#ifndef CERNLIB_QUNIX
#define CERNLIB_QUNIX
#endif
