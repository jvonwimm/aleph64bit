#if 0
* This pilot patch was created from kerngent.car patch _mcru
#endif
#if 0
*    For CRAY with system UNICOS
#endif
#ifndef CERNLIB__MICKY
#define CERNLIB__MICKY
#endif
#ifndef CERNLIB_QMCRU
#define CERNLIB_QMCRU
#endif
#ifndef CERNLIB_QUNIX
#define CERNLIB_QUNIX
#endif
#ifndef CERNLIB_A8
#define CERNLIB_A8
#endif
#ifndef CERNLIB_B64
#define CERNLIB_B64
#endif
#if 0
*               do not test VXINVB/C
#endif
#ifdef CERNLIB_TVXINV
#undef CERNLIB_TVXINV
#endif
