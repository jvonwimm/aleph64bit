#if 0
* This pilot patch was created from kerngent.car patch _mdge
#endif
#if 0
*    For DATA GENERAL ECLIPSE
#endif
#ifndef CERNLIB__MICKY
#define CERNLIB__MICKY
#endif
#ifndef CERNLIB_A4
#define CERNLIB_A4
#endif
#ifndef CERNLIB_B32
#define CERNLIB_B32
#endif
