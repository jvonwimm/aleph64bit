*
* $Id: sycern.h,v 1.1.1.1 1996/02/15 17:53:19 mclareni Exp $
*
* $Log: sycern.h,v $
* Revision 1.1.1.1  1996/02/15 17:53:19  mclareni
* Kernlib
*
*
* This directory was created from kernibm.car patch sycern
#ifndef CERNLIB_SYMVSSP
#define CERNLIB_SYMVSSP
#endif
*    ROUTINES RELYING ON CERN SYSTEM MODIFICATIONS
