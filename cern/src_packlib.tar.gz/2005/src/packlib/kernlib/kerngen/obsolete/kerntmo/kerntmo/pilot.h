#if 0
* This pilot patch was created from kerntmo.car patch _ktmo
#endif
#ifndef CERNLIB_QMTMO
#define CERNLIB_QMTMO
#endif
#ifndef CERNLIB_TMOGS
#define CERNLIB_TMOGS
#endif
#ifndef CERNLIB_TMOSYS
#define CERNLIB_TMOSYS
#endif
#ifndef CERNLIB_XVECT
#define CERNLIB_XVECT
#endif
#ifndef CERNLIB_TCGEN
#define CERNLIB_TCGEN
#endif
#ifdef CERNLIB_TCGEN_BTEST
#undef CERNLIB_TCGEN_BTEST
#endif
#ifdef CERNLIB_TCGEN_!!IBITS
#undef CERNLIB_TCGEN_!!IBITS
#endif
#ifdef CERNLIB_TCGEN_IBCLR
#undef CERNLIB_TCGEN_IBCLR
#endif
#ifdef CERNLIB_TCGEN_IBSET
#undef CERNLIB_TCGEN_IBSET
#endif
#ifdef CERNLIB_TCGEN_MVBITS
#undef CERNLIB_TCGEN_MVBITS
#endif
#ifdef CERNLIB_TCGEN_ISHFT
#undef CERNLIB_TCGEN_ISHFT
#endif
#ifdef CERNLIB_TCGEN_ISHFTC
#undef CERNLIB_TCGEN_ISHFTC
#endif
