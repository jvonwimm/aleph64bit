*
* $Id: qmibx.h,v 1.1.1.1 1996/02/15 17:54:30 mclareni Exp $
*
* $Log: qmibx.h,v $
* Revision 1.1.1.1  1996/02/15 17:54:30  mclareni
* Kernlib
*
*
* This directory was created from kernibx.car patch qmibx
#ifndef CERNLIB_A4
#define CERNLIB_A4
#endif
#ifndef CERNLIB_B32
#define CERNLIB_B32
#endif
#ifndef CERNLIB_HEX
#define CERNLIB_HEX
#endif
*                 Normal Unix system machine
#ifndef CERNLIB_QMUIX
#define CERNLIB_QMUIX
#endif
*               Posix call for setjmp/longjmp
#ifndef CERNLIB_QSIGJMP
#define CERNLIB_QSIGJMP
#endif
*              Double indirect adr for externals
#ifndef CERNLIB_QCCINDAD
#define CERNLIB_QCCINDAD
#endif
#ifndef CERNLIB_QX_SCEXTERNALNAMESWITHUNDERSCORES
#define CERNLIB_QX_SCEXTERNALNAMESWITHUNDERSCORES
#endif
*                Character set is ASCII
#ifndef CERNLIB_QASCII
#define CERNLIB_QASCII
#endif
*                 Hollerith constants exist
#ifndef CERNLIB_QHOLL
#define CERNLIB_QHOLL
#endif
*              EQUIVALENCE Hollerith/Character ok
#ifndef CERNLIB_EQUHOLCH
#define CERNLIB_EQUHOLCH
#endif
*              Orthodox Hollerith storage left to right
#ifndef CERNLIB_QORTHOLL
#define CERNLIB_QORTHOLL
#endif
*               ISA standard functions available
#ifndef CERNLIB_QISASTD
#define CERNLIB_QISASTD
#endif
