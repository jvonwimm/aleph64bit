*
* $Id: symvsse.h,v 1.1.1.1 1996/02/15 17:52:59 mclareni Exp $
*
* $Log: symvsse.h,v $
* Revision 1.1.1.1  1996/02/15 17:52:59  mclareni
* Kernlib
*
*
* This directory was created from kernibm.car patch symvsse
#ifndef CERNLIB_SYMVS
#define CERNLIB_SYMVS
#endif
*    ROUTINES FOR IBM SYSTEM  MVS / SE
