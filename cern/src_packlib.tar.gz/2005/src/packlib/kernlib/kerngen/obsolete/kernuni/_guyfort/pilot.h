#if 0
* This pilot patch was created from kernuni.car patch _guyfort
#endif
#ifndef CERNLIB_GUYFORT
#define CERNLIB_GUYFORT
#endif
#if !defined(CERNLIB_U1110)
#ifndef CERNLIB_U1108
#define CERNLIB_U1108
#endif
#endif
+EXE,GUYFORT_
#ifndef CERNLIB_GUY
#define CERNLIB_GUY
#endif
#ifndef CERNLIB_TCGEN
#define CERNLIB_TCGEN
#endif
#ifndef CERNLIB_XVECTUNI
#define CERNLIB_XVECTUNI
#endif
#ifndef CERNLIB_QMUNI
#define CERNLIB_QMUNI
#endif
