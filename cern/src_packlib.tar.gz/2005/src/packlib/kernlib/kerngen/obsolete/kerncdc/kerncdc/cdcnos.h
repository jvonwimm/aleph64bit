*
* $Id: cdcnos.h,v 1.1.1.1 1996/02/15 17:51:13 mclareni Exp $
*
* $Log: cdcnos.h,v $
* Revision 1.1.1.1  1996/02/15 17:51:13  mclareni
* Kernlib
*
*
* This directory was created from kerncdc.car patch cdcnos
#ifndef CERNLIB_CDCSYS
#define CERNLIB_CDCSYS
#endif
