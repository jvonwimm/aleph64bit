#if 0
* This pilot patch was created from kernapo.car patch _kapof77
#endif
#if 0
*            for Apollo with f77
#endif
#ifndef CERNLIB_ANYAPO
#define CERNLIB_ANYAPO
#endif
#ifndef CERNLIB_QF_APO77
#define CERNLIB_QF_APO77
#endif
#ifndef CERNLIB_QMAPOF77
#define CERNLIB_QMAPOF77
#endif
#if 0
*                 external names with underscores
#endif
#ifndef CERNLIB_QX_SC
#define CERNLIB_QX_SC
#endif
