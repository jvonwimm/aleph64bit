#if 0
* This pilot patch was created from kernibm.car patch _kicernv
#endif
#if 0
*    Pilot Cern IBM, Fort 77, system VM/CMS
#endif
#ifndef CERNLIB_SYCERNV
#define CERNLIB_SYCERNV
#endif
#ifndef CERNLIB__KIVM
#define CERNLIB__KIVM
#endif
