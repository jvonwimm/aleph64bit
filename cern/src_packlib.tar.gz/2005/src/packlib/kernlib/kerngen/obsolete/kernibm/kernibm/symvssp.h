*
* $Id: symvssp.h,v 1.1.1.1 1996/02/15 17:53:00 mclareni Exp $
*
* $Log: symvssp.h,v $
* Revision 1.1.1.1  1996/02/15 17:53:00  mclareni
* Kernlib
*
*
* This directory was created from kernibm.car patch symvssp
#ifndef CERNLIB_SYMVSSE
#define CERNLIB_SYMVSSE
#endif
*    ROUTINES FOR IBM SYSTEM  MVS / SP
