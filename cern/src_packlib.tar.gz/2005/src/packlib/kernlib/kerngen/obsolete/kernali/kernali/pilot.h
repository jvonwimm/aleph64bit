#if 0
* This pilot patch was created from kernali.car patch _kali
* This directory was created from kernali.car patch qmali
#endif
#ifndef CERNLIB_A4
#define CERNLIB_A4
#endif
#ifndef CERNLIB_B32
#define CERNLIB_B32
#endif
#ifndef CERNLIB_HEX
#define CERNLIB_HEX
#endif
#ifndef CERNLIB_QISASTD
#define CERNLIB_QISASTD
#endif
#ifndef CERNLIB_BSD42
#define CERNLIB_BSD42
#endif
#ifndef CERNLIB_ALIGS
#define CERNLIB_ALIGS
#endif
#ifndef CERNLIB_XVECT
#define CERNLIB_XVECT
#endif
#ifndef CERNLIB_TCGEN
#define CERNLIB_TCGEN
#endif
#ifndef CERNLIB_CCGEN_ABEND
#define CERNLIB_CCGEN_ABEND
#endif
#ifndef CERNLIB_CCGEN_DATIME
#define CERNLIB_CCGEN_DATIME
#endif
#ifndef CERNLIB_CCGEN_DATIMH
#define CERNLIB_CCGEN_DATIMH
#endif
#ifndef CERNLIB_CCGEN_INTRAC
#define CERNLIB_CCGEN_INTRAC
#endif
#ifndef CERNLIB_CCGEN_LOCB
#define CERNLIB_CCGEN_LOCB
#endif
#ifndef CERNLIB_CCGEN_LOCF
#define CERNLIB_CCGEN_LOCF
#endif
#ifndef CERNLIB_CCGEN_TIMEL
#define CERNLIB_CCGEN_TIMEL
#endif
#ifndef CERNLIB_CCGEN_TMNBUF
#define CERNLIB_CCGEN_TMNBUF
#endif
#ifndef CERNLIB_CCGEN_TMPROM
#define CERNLIB_CCGEN_TMPROM
#endif
#ifndef CERNLIB_CCGEN_TMREAD
#define CERNLIB_CCGEN_TMREAD
#endif
