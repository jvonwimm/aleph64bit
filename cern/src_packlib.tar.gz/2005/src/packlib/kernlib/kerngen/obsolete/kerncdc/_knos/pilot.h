#if 0
* This pilot patch was created from kerncdc.car patch _knos
#endif
#if 0
*       KERNLIB CDC FORTRAN 4 FOR NOS
#endif
#if 0
*                 FORTRAN VERSION 4.7  (SEE D=KFILE)
#endif
#ifndef CERNLIB_FTN47
#define CERNLIB_FTN47
#endif
#ifndef CERNLIB_XVECTCDC
#define CERNLIB_XVECTCDC
#endif
#ifndef CERNLIB_XSCOPE3
#define CERNLIB_XSCOPE3
#endif
#ifndef CERNLIB_CDCNOS
#define CERNLIB_CDCNOS
#endif
#ifndef CERNLIB__KCDC
#define CERNLIB__KCDC
#endif
#ifndef CERNLIB_CDC60SYS_JOBNAM
#define CERNLIB_CDC60SYS_JOBNAM
#endif
#ifndef CERNLIB_CDC60SYS_REPINIT
#define CERNLIB_CDC60SYS_REPINIT
#endif
#ifdef CERNLIB_CDCSYS_INCMEM
#undef CERNLIB_CDCSYS_INCMEM
#endif
