#if 0
* This pilot patch was created from kernpdp.car patch _kpdp10
#endif
#ifndef CERNLIB_HELP
#define CERNLIB_HELP
#endif
#ifndef CERNLIB_PDP10MLN
#define CERNLIB_PDP10MLN
#endif
#ifndef CERNLIB_PDP10MLR
#define CERNLIB_PDP10MLR
#endif
#ifndef CERNLIB_TCGEN
#define CERNLIB_TCGEN
#endif
#ifndef CERNLIB_XVECT
#define CERNLIB_XVECT
#endif
