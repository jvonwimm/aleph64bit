#if 0
* This pilot patch was created from kernibx.car patch _kibx
#endif
#if 0
*               Pilot IBM 3090, system AIX
#endif
#ifndef CERNLIB_QMIBX
#define CERNLIB_QMIBX
#endif
#ifndef CERNLIB_IBXGS
#define CERNLIB_IBXGS
#endif
#ifndef CERNLIB_IBXSYS
#define CERNLIB_IBXSYS
#endif
#ifndef CERNLIB_CCGEN
#define CERNLIB_CCGEN
#endif
#ifndef CERNLIB_CCGENCF
#define CERNLIB_CCGENCF
#endif
#ifndef CERNLIB_XVECT
#define CERNLIB_XVECT
#endif
#ifndef CERNLIB_TCGEN
#define CERNLIB_TCGEN
#endif
