*
* $Id: sycernv.h,v 1.1.1.1 1996/02/15 17:52:59 mclareni Exp $
*
* $Log: sycernv.h,v $
* Revision 1.1.1.1  1996/02/15 17:52:59  mclareni
* Kernlib
*
*
* This directory was created from kernibm.car patch sycernv
#if !defined(CERNLIB_SYCERNV)

The material for running under VM/CMS at CERN is found
on the separate Pam file KERNCMS.

#endif
