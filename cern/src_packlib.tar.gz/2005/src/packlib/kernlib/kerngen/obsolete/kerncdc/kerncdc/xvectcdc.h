*
* $Id: xvectcdc.h,v 1.1.1.1 1996/02/15 17:51:13 mclareni Exp $
*
* $Log: xvectcdc.h,v $
* Revision 1.1.1.1  1996/02/15 17:51:13  mclareni
* Kernlib
*
*
* This directory was created from kerncdc.car patch xvectcdc
#ifndef CERNLIB_XVECT
#define CERNLIB_XVECT
#endif
#ifdef CERNLIB_XVECT_XINB
#undef CERNLIB_XVECT_XINB
#endif
#ifdef CERNLIB_XVECT_XINBF
#undef CERNLIB_XVECT_XINBF
#endif
#ifdef CERNLIB_XVECT_XINBS
#undef CERNLIB_XVECT_XINBS
#endif
#ifdef CERNLIB_XVECT_XINCF
#undef CERNLIB_XVECT_XINCF
#endif
