*
* $Id: qf_ibm.h,v 1.1.1.1 1996/02/15 17:53:02 mclareni Exp $
*
* $Log: qf_ibm.h,v $
* Revision 1.1.1.1  1996/02/15 17:53:02  mclareni
* Kernlib
*
*
*    For IBM with VS compiler
* This directory was created from kernibm.car patch qf_ibm
#ifndef CERNLIB_B32
#define CERNLIB_B32
#endif
#ifndef CERNLIB_A4
#define CERNLIB_A4
#endif
#ifndef CERNLIB_HEX
#define CERNLIB_HEX
#endif
#ifndef CERNLIB_QMIBM
#define CERNLIB_QMIBM
#endif
