#if 0
* This pilot patch was created from kerncdc.car patch _kvnos
#endif
#if 0
*      KERNLIB CDC FORTRAN 5 FOR NOS
#endif
#ifndef CERNLIB_F77
#define CERNLIB_F77
#endif
#if 0
*                 FORTRAN VERSION 4.7  (SEE D=KFILE)
#endif
#ifndef CERNLIB_FTN47
#define CERNLIB_FTN47
#endif
#ifndef CERNLIB_XIOCDCV
#define CERNLIB_XIOCDCV
#endif
#ifndef CERNLIB_CDCNOS
#define CERNLIB_CDCNOS
#endif
#ifndef CERNLIB__KCDC
#define CERNLIB__KCDC
#endif
#ifndef CERNLIB_QMCDCV
#define CERNLIB_QMCDCV
#endif
#ifndef CERNLIB_XSCOPE_LXBITS
#define CERNLIB_XSCOPE_LXBITS
#endif
#ifndef CERNLIB_CDC60SYS_JOBNAM
#define CERNLIB_CDC60SYS_JOBNAM
#endif
#ifndef CERNLIB_CDC60SYS_REPINIT
#define CERNLIB_CDC60SYS_REPINIT
#endif
#ifdef CERNLIB_CDCSYS_INCMEM
#undef CERNLIB_CDCSYS_INCMEM
#endif
