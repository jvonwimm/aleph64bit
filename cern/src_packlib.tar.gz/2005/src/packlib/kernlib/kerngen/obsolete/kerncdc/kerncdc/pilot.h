#if 0
* This pilot patch was created from kerncdc.car patch _kcdc
#endif
#ifndef CERNLIB_QMCDC
#define CERNLIB_QMCDC
#endif
#ifndef CERNLIB_TCGEN
#define CERNLIB_TCGEN
#endif
#ifndef CERNLIB_CDCFTN
#define CERNLIB_CDCFTN
#endif
#ifdef CERNLIB_TCGEN_LOCF
#undef CERNLIB_TCGEN_LOCF
#endif
#ifndef CERNLIB_B60
#define CERNLIB_B60
#endif
#ifndef CERNLIB_B60M
#define CERNLIB_B60M
#endif
#ifndef CERNLIB_B48M
#define CERNLIB_B48M
#endif
#ifndef CERNLIB_B36M
#define CERNLIB_B36M
#endif
#ifndef CERNLIB_A10
#define CERNLIB_A10
#endif
#ifndef CERNLIB_A8M
#define CERNLIB_A8M
#endif
#ifndef CERNLIB_A6M
#define CERNLIB_A6M
#endif
#ifndef CERNLIB_A5M
#define CERNLIB_A5M
#endif
#if 0
*    In-line AND / OR
#endif
#ifndef CERNLIB_QANDORINL
#define CERNLIB_QANDORINL
#endif
#if 0
*    In-line SHIFT L/R
#endif
#ifndef CERNLIB_QSHIFTINL
#define CERNLIB_QSHIFTINL
#endif
#ifndef CERNLIB_QSHICOINL
#define CERNLIB_QSHICOINL
#endif
