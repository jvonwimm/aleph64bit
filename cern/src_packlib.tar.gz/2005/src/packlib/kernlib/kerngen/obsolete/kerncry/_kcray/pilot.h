#if 0
* This pilot patch was created from kerncry.car patch _kcray
#endif
#if 0
*    Pilot for system COS
#endif
#ifndef CERNLIB_QMCRY
#define CERNLIB_QMCRY
#endif
#ifndef CERNLIB_CRYGS
#define CERNLIB_CRYGS
#endif
#ifndef CERNLIB_CRYCOS
#define CERNLIB_CRYCOS
#endif
#ifndef CERNLIB_TCGEN
#define CERNLIB_TCGEN
#endif
#ifndef CERNLIB_XVECT
#define CERNLIB_XVECT
#endif
