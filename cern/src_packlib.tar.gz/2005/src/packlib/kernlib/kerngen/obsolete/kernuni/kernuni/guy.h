*
* $Id: guy.h,v 1.1.1.1 1996/02/15 17:53:52 mclareni Exp $
*
* $Log: guy.h,v $
* Revision 1.1.1.1  1996/02/15 17:53:52  mclareni
* Kernlib
*
*
* This directory was created from kernuni.car patch guy
*      THERE IS A FAULT !!
#ifdef CERNLIB_GUY_JRSBYT
#undef CERNLIB_GUY_JRSBYT
#endif
