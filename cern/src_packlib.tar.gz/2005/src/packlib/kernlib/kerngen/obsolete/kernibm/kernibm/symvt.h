*
* $Id: symvt.h,v 1.1.1.1 1996/02/15 17:53:00 mclareni Exp $
*
* $Log: symvt.h,v $
* Revision 1.1.1.1  1996/02/15 17:53:00  mclareni
* Kernlib
*
*
* This directory was created from kernibm.car patch symvt
#ifndef CERNLIB_SYOS
#define CERNLIB_SYOS
#endif
