*
* $Id: qmhywgc.h,v 1.1.1.1 1996/02/15 17:52:47 mclareni Exp $
*
* $Log: qmhywgc.h,v $
* Revision 1.1.1.1  1996/02/15 17:52:47  mclareni
* Kernlib
*
*
* This directory was created from kernhyw.car patch qmhywgc
#ifndef CERNLIB_F77
#define CERNLIB_F77
#endif
#ifndef CERNLIB_B36
#define CERNLIB_B36
#endif
#ifndef CERNLIB_B36M
#define CERNLIB_B36M
#endif
#ifndef CERNLIB_A4
#define CERNLIB_A4
#endif
*    In-line AND / OR
#ifndef CERNLIB_QANDORINL
#define CERNLIB_QANDORINL
#endif
*    In-line SHIFT L/R
#ifndef CERNLIB_QSHIFTINL
#define CERNLIB_QSHIFTINL
#endif
#ifndef CERNLIB_QSHICOINL
#define CERNLIB_QSHICOINL
#endif
