*
* $Id: cdc76sys.h,v 1.1.1.1 1996/02/15 17:51:13 mclareni Exp $
*
* $Log: cdc76sys.h,v $
* Revision 1.1.1.1  1996/02/15 17:51:13  mclareni
* Kernlib
*
*
* This directory was created from kerncdc.car patch cdc76sys
#ifndef CERNLIB_CDCSYS
#define CERNLIB_CDCSYS
#endif
