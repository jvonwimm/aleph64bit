*
* $Id: qmapo.h,v 1.1.1.1 1996/02/15 17:50:59 mclareni Exp $
*
* $Log: qmapo.h,v $
* Revision 1.1.1.1  1996/02/15 17:50:59  mclareni
* Kernlib
*
*
* This directory was created from kernapo.car patch qmapo
#ifndef CERNLIB_A4
#define CERNLIB_A4
#endif
#ifndef CERNLIB_B32
#define CERNLIB_B32
#endif
#ifndef CERNLIB_HEX
#define CERNLIB_HEX
#endif
*                Character set is ASCII
#ifndef CERNLIB_QASCII
#define CERNLIB_QASCII
#endif
*                 Hollerith constants exist
#ifndef CERNLIB_QHOLL
#define CERNLIB_QHOLL
#endif
*              EQUIVALENCE Hollerith/Character ok
#ifndef CERNLIB_EQUHOLCH
#define CERNLIB_EQUHOLCH
#endif
*              Orthodox Hollerith storage left to right
#ifndef CERNLIB_QORTHOLL
#define CERNLIB_QORTHOLL
#endif
*              Internal double-precision
#ifndef CERNLIB_INTDOUBL
#define CERNLIB_INTDOUBL
#endif
*                 IEEE floating point
#ifndef CERNLIB_QIEEE
#define CERNLIB_QIEEE
#endif
