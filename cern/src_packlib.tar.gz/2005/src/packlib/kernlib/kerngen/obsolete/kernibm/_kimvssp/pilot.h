#if 0
* This pilot patch was created from kernibm.car patch _kimvssp
#endif
#if 0
*            Pilot IBM, system OS MVS/SP
#endif
#ifndef CERNLIB_SYMVSSP
#define CERNLIB_SYMVSSP
#endif
#ifndef CERNLIB__KIOS
#define CERNLIB__KIOS
#endif
