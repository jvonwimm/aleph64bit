*
* $Id: sycernv.h,v 1.1.1.1 1996/02/15 17:51:42 mclareni Exp $
*
* $Log: sycernv.h,v $
* Revision 1.1.1.1  1996/02/15 17:51:42  mclareni
* Kernlib
*
*
* This directory was created from kerncms.car patch sycernv
#ifndef CERNLIB_SKERNCMS
#define CERNLIB_SKERNCMS
#endif
#ifndef CERNLIB_CERN
#define CERNLIB_CERN
#endif
