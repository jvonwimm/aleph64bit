#if 0
* This pilot patch was created from kernibm.car patch _kimvt
#endif
#if 0
*      Pilot IBM, system OS MVT
#endif
#ifndef CERNLIB_SYMVT
#define CERNLIB_SYMVT
#endif
#ifndef CERNLIB__KIOS
#define CERNLIB__KIOS
#endif
