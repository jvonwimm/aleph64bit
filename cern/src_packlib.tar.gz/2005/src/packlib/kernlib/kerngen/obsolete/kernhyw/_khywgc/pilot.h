#if 0
* This pilot patch was created from kernhyw.car patch _khywgc
#endif
#ifndef CERNLIB_QMHYW
#define CERNLIB_QMHYW
#endif
#ifndef CERNLIB_QMHYWGC
#define CERNLIB_QMHYWGC
#endif
#ifndef CERNLIB_HYWGC
#define CERNLIB_HYWGC
#endif
#ifndef CERNLIB_XVECT
#define CERNLIB_XVECT
#endif
#ifndef CERNLIB_TCGEN
#define CERNLIB_TCGEN
#endif
#ifdef CERNLIB_TCGEN_BTEST
#undef CERNLIB_TCGEN_BTEST
#endif
#ifdef CERNLIB_TCGEN_IBITS
#undef CERNLIB_TCGEN_IBITS
#endif
#ifdef CERNLIB_TCGEN_IBCLR
#undef CERNLIB_TCGEN_IBCLR
#endif
#ifdef CERNLIB_TCGEN_IBSET
#undef CERNLIB_TCGEN_IBSET
#endif
#ifdef CERNLIB_TCGEN_MVBITS
#undef CERNLIB_TCGEN_MVBITS
#endif
#ifdef CERNLIB_TCGEN_ISHFT
#undef CERNLIB_TCGEN_ISHFT
#endif
#ifdef CERNLIB_TCGEN_ISHFTC
#undef CERNLIB_TCGEN_ISHFTC
#endif
