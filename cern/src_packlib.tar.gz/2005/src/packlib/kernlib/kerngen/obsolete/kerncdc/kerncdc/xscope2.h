*
* $Id: xscope2.h,v 1.1.1.1 1996/02/15 17:51:13 mclareni Exp $
*
* $Log: xscope2.h,v $
* Revision 1.1.1.1  1996/02/15 17:51:13  mclareni
* Kernlib
*
*
* This directory was created from kerncdc.car patch xscope2
#ifndef CERNLIB_XSCOPE
#define CERNLIB_XSCOPE
#endif
