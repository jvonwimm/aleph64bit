*
* $Id: xiocdcv.h,v 1.1.1.1 1996/02/15 17:51:13 mclareni Exp $
*
* $Log: xiocdcv.h,v $
* Revision 1.1.1.1  1996/02/15 17:51:13  mclareni
* Kernlib
*
*
* This directory was created from kerncdc.car patch xiocdcv
#ifndef CERNLIB_XVECT
#define CERNLIB_XVECT
#endif
#ifndef CERNLIB_XSCOPE_XSETIO
#define CERNLIB_XSCOPE_XSETIO
#endif
#ifndef CERNLIB_XSCOPE_XERROR
#define CERNLIB_XSCOPE_XERROR
#endif
