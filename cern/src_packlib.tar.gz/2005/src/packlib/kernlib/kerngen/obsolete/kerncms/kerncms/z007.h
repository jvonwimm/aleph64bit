*
* $Id: z007.h,v 1.1.1.1 1996/02/15 17:51:44 mclareni Exp $
*
* $Log: z007.h,v $
* Revision 1.1.1.1  1996/02/15 17:51:44  mclareni
* Kernlib
*
*
* This directory was created from kerncms.car patch z007
#ifdef CERNLIB_TCGEN_TIMED
#undef CERNLIB_TCGEN_TIMED
#endif
#ifdef CERNLIB_TCGEN_TIMEL
#undef CERNLIB_TCGEN_TIMEL
#endif
#ifdef CERNLIB_TCGEN_TIMEX
#undef CERNLIB_TCGEN_TIMEX
#endif
#ifdef CERNLIB_TCGEN_TIMEST
#undef CERNLIB_TCGEN_TIMEST
#endif
