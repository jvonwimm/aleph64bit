*
* $Id: syvm.h,v 1.1.1.1 1996/02/15 17:53:00 mclareni Exp $
*
* $Log: syvm.h,v $
* Revision 1.1.1.1  1996/02/15 17:53:00  mclareni
* Kernlib
*
*
* This directory was created from kernibm.car patch syvm
#ifndef CERNLIB_SYVMOS
#define CERNLIB_SYVMOS
#endif
#ifdef CERNLIB_SYOS_DATIME
#undef CERNLIB_SYOS_DATIME
#endif
#ifdef CERNLIB_SYOS_DATIMH
#undef CERNLIB_SYOS_DATIMH
#endif
#ifndef CERNLIB_SYOS_DTZ007
#define CERNLIB_SYOS_DTZ007
#endif
#ifndef CERNLIB_SYOS_NOARG
#define CERNLIB_SYOS_NOARG
#endif
