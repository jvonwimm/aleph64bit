#if 0
* This pilot patch was created from kerncvx.car patch _kcvy
#endif
#if 0
*          32-bit, IEEE fp mode
#endif
#ifndef CERNLIB_QIEEE
#define CERNLIB_QIEEE
#endif
#ifndef CERNLIB_QMCVX
#define CERNLIB_QMCVX
#endif
#ifndef CERNLIB_QMCV32
#define CERNLIB_QMCV32
#endif
#ifdef CERNLIB_TCGEN_IBITS
#undef CERNLIB_TCGEN_IBITS
#endif
#ifdef CERNLIB_TCGEN_ISHFTC
#undef CERNLIB_TCGEN_ISHFTC
#endif
#ifdef CERNLIB_TCGEN_LNBLNK
#undef CERNLIB_TCGEN_LNBLNK
#endif
