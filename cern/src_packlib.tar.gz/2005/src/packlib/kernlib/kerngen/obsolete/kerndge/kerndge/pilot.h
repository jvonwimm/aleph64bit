#if 0
* This pilot patch was created from kerndge.car patch _kdge
#endif
#ifndef CERNLIB_QMDGE
#define CERNLIB_QMDGE
#endif
#ifndef CERNLIB_DGEGS
#define CERNLIB_DGEGS
#endif
#ifndef CERNLIB_DGESYS
#define CERNLIB_DGESYS
#endif
#ifndef CERNLIB_XVECT
#define CERNLIB_XVECT
#endif
#ifndef CERNLIB_TCGEN
#define CERNLIB_TCGEN
#endif
#ifdef CERNLIB_TCGEN_BTEST
#undef CERNLIB_TCGEN_BTEST
#endif
#ifdef CERNLIB_TCGEN_IBITS
#undef CERNLIB_TCGEN_IBITS
#endif
#ifdef CERNLIB_TCGEN_IBCLR
#undef CERNLIB_TCGEN_IBCLR
#endif
#ifdef CERNLIB_TCGEN_IBSET
#undef CERNLIB_TCGEN_IBSET
#endif
#ifdef CERNLIB_TCGEN_MVBITS
#undef CERNLIB_TCGEN_MVBITS
#endif
#ifdef CERNLIB_TCGEN_ISHFT
#undef CERNLIB_TCGEN_ISHFT
#endif
#ifdef CERNLIB_TCGEN_ISHFTC
#undef CERNLIB_TCGEN_ISHFTC
#endif
