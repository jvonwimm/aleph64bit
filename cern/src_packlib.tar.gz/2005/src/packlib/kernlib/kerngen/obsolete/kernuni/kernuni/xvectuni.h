*
* $Id: xvectuni.h,v 1.1.1.1 1996/02/15 17:53:53 mclareni Exp $
*
* $Log: xvectuni.h,v $
* Revision 1.1.1.1  1996/02/15 17:53:53  mclareni
* Kernlib
*
*
* This directory was created from kernuni.car patch xvectuni
#ifndef CERNLIB_XVECT
#define CERNLIB_XVECT
#endif
