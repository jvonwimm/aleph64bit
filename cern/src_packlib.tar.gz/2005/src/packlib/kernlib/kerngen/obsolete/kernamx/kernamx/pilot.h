#if 0
* This pilot patch was created from kernamx.car patch _kamx
* This directory was created from kernamx.car patch qmamx
#endif
#ifndef CERNLIB_F77
#define CERNLIB_F77
#endif
#ifndef CERNLIB_A4
#define CERNLIB_A4
#endif
#ifndef CERNLIB_B32
#define CERNLIB_B32
#endif
#ifndef CERNLIB_HEX
#define CERNLIB_HEX
#endif
#if 0
*       Normal Unix system machine
#endif
#ifndef CERNLIB_QMUIX
#define CERNLIB_QMUIX
#endif
#if 0
*      Posix call for setjmp/longjmp
#endif
#ifndef CERNLIB_QPOSIX
#define CERNLIB_QPOSIX
#endif
#if 0
*     MIL standard routines, IBITS, MVBITS, ISHFTC
#endif
#ifndef CERNLIB_QMILSTD
#define CERNLIB_QMILSTD
#endif
#if 0
*     ISA standard routines, ISHFT, IOR, etc
#endif
#ifndef CERNLIB_QISASTD
#define CERNLIB_QISASTD
#endif
#if 0
*       External names with underscore
#endif
#ifndef CERNLIB_QX_SC
#define CERNLIB_QX_SC
#endif
#if 0
*       IEEE floating point
#endif
#ifndef CERNLIB_QIEEE
#define CERNLIB_QIEEE
#endif
#if 0
*      Character set is ASCII
#endif
#ifndef CERNLIB_QASCII
#define CERNLIB_QASCII
#endif
#if 0
*       Hollerith constants exist
#endif
#ifndef CERNLIB_QHOLL
#define CERNLIB_QHOLL
#endif
#if 0
*    EQUIVALENCE Hollerith/Character ok
#endif
#ifndef CERNLIB_EQUHOLCH
#define CERNLIB_EQUHOLCH
#endif
#if 0
*    Orthodox Hollerith storage left to right
#endif
#ifndef CERNLIB_QORTHOLL
#define CERNLIB_QORTHOLL
#endif
#ifndef CERNLIB_AMXGS
#define CERNLIB_AMXGS
#endif
#ifndef CERNLIB_XVECT
#define CERNLIB_XVECT
#endif
#ifndef CERNLIB_TCGEN
#define CERNLIB_TCGEN
#endif
#ifndef CERNLIB_CCGEN
#define CERNLIB_CCGEN
#endif
#ifndef CERNLIB_CCGENCF
#define CERNLIB_CCGENCF
#endif
