*
* $Id: qmnxt.h,v 1.1.1.1 1996/02/15 17:53:29 mclareni Exp $
*
* $Log: qmnxt.h,v $
* Revision 1.1.1.1  1996/02/15 17:53:29  mclareni
* Kernlib
*
*
* This directory was created from kernnxt.car patch qmnxt
#ifndef CERNLIB_F77
#define CERNLIB_F77
#endif
#ifndef CERNLIB_A4
#define CERNLIB_A4
#endif
#ifndef CERNLIB_B32
#define CERNLIB_B32
#endif
#ifndef CERNLIB_HEX
#define CERNLIB_HEX
#endif
*                 Normal Unix system machine
#ifndef CERNLIB_QMUIX
#define CERNLIB_QMUIX
#endif
*              Default option setting
#ifndef CERNLIB_QDEFAULT
#define CERNLIB_QDEFAULT
#endif
*                 external names with underscore
#ifndef CERNLIB_QX_SC
#define CERNLIB_QX_SC
#endif
*               running BSD
#ifndef CERNLIB_QSYSBSD
#define CERNLIB_QSYSBSD
#endif
#ifndef CERNLIB_QIEEE
#define CERNLIB_QIEEE
#endif
*     ISA standard routines, ISHFT, IOR, etc
#ifndef CERNLIB_QISASTD
#define CERNLIB_QISASTD
#endif
*     MIL standard routines, IBITS, MVBITS, ISHFTC
#ifndef CERNLIB_QMILSTD
#define CERNLIB_QMILSTD
#endif
