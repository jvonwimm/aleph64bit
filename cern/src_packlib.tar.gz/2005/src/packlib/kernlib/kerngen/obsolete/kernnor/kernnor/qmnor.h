*
* $Id: qmnor.h,v 1.1.1.1 1996/02/15 17:54:46 mclareni Exp $
*
* $Log: qmnor.h,v $
* Revision 1.1.1.1  1996/02/15 17:54:46  mclareni
* Kernlib
*
*
* This directory was created from kernnor.car patch qmnd3
#ifndef CERNLIB_F77
#define CERNLIB_F77
#endif
#ifndef CERNLIB_B32
#define CERNLIB_B32
#endif
#ifndef CERNLIB_A4
#define CERNLIB_A4
#endif
#ifndef CERNLIB_HEX
#define CERNLIB_HEX
#endif
