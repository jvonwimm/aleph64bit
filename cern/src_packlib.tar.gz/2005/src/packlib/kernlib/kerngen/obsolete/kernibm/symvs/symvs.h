*
* $Id: symvs.h,v 1.1.1.1 1996/02/15 17:53:20 mclareni Exp $
*
* $Log: symvs.h,v $
* Revision 1.1.1.1  1996/02/15 17:53:20  mclareni
* Kernlib
*
*
* This directory was created from kernibm.car patch symvs
#ifndef CERNLIB_SYOS
#define CERNLIB_SYOS
#endif
*    ROUTINES FOR IBM SYSTEM  MVS
