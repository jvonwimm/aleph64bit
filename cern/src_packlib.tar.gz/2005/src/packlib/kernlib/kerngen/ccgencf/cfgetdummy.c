#ifndef CERNLIB_CFGET_CHARACTER
#define CERNLIB_CFGET_CHARACTER
#endif

#include "cfget.c"

#ifdef CERNLIB_CFGET_CHARACTER
#undef CERNLIB_CFGET_CHARACTER
#endif
