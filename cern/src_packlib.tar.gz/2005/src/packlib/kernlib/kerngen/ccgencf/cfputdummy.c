#ifndef CERNLIB_CFPUT_CHARACTER
#define CERNLIB_CFPUT_CHARACTER
#endif

#include "cfput.c"

#ifdef CERNLIB_CFPUT_CHARACTER
#undef CERNLIB_CFPUT_CHARACTER
#endif
