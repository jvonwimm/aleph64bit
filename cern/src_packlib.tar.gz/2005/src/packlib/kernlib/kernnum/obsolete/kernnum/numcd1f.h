*
* $Id: numcd1f.h,v 1.1.1.1 1996/02/15 17:47:58 mclareni Exp $
*
* $Log: numcd1f.h,v $
* Revision 1.1.1.1  1996/02/15 17:47:58  mclareni
* Kernlib
*
*
* This directory was created from kernnum.car patch numcd1f
#ifndef CERNLIB_NUMCD
#define CERNLIB_NUMCD
#endif
#ifndef CERNLIB_NUMFORT
#define CERNLIB_NUMFORT
#endif
#ifndef CERNLIB_NUMFTOPT
#define CERNLIB_NUMFTOPT
#endif
