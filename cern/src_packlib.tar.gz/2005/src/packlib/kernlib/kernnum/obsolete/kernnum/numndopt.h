*
* $Id: numndopt.h,v 1.1.1.1 1996/02/15 17:47:58 mclareni Exp $
*
* $Log: numndopt.h,v $
* Revision 1.1.1.1  1996/02/15 17:47:58  mclareni
* Kernlib
*
*
* This directory was created from kernnum.car patch numndopt
#ifndef CERNLIB_G900ND
#define CERNLIB_G900ND
#endif
#ifndef CERNLIB_E208FORT
#define CERNLIB_E208FORT
#endif
#ifndef CERNLIB_F002FORT
#define CERNLIB_F002FORT
#endif
#ifndef CERNLIB_F003FORT
#define CERNLIB_F003FORT
#endif
#ifndef CERNLIB_F004FORT
#define CERNLIB_F004FORT
#endif
#ifndef CERNLIB_F011FORT
#define CERNLIB_F011FORT
#endif
#ifndef CERNLIB_F012FORT
#define CERNLIB_F012FORT
#endif
