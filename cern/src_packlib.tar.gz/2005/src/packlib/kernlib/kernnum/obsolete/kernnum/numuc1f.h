*
* $Id: numuc1f.h,v 1.1.1.1 1996/02/15 17:47:58 mclareni Exp $
*
* $Log: numuc1f.h,v $
* Revision 1.1.1.1  1996/02/15 17:47:58  mclareni
* Kernlib
*
*
* This directory was created from kernnum.car patch numuc1f
#ifndef CERNLIB_NUMUC
#define CERNLIB_NUMUC
#endif
#ifndef CERNLIB_NUMFORT
#define CERNLIB_NUMFORT
#endif
#ifndef CERNLIB_NUMFTOPT
#define CERNLIB_NUMFTOPT
#endif
