*
* $Id: numib2c.h,v 1.1.1.1 1996/02/15 17:48:38 mclareni Exp $
*
* $Log: numib2c.h,v $
* Revision 1.1.1.1  1996/02/15 17:48:38  mclareni
* Kernlib
*
*
* This directory was created from kernnumt.car patch numib2c
#ifndef CERNLIB_NUMIB2
#define CERNLIB_NUMIB2
#endif
#ifndef CERNLIB_NUMIB
#define CERNLIB_NUMIB
#endif
#ifndef CERNLIB_NUMCHK
#define CERNLIB_NUMCHK
#endif
