*
* $Id: numcd1c.h,v 1.1.1.1 1996/02/15 17:48:38 mclareni Exp $
*
* $Log: numcd1c.h,v $
* Revision 1.1.1.1  1996/02/15 17:48:38  mclareni
* Kernlib
*
*
* This directory was created from kernnumt.car patch numcd1c
#ifndef CERNLIB_NUMCD
#define CERNLIB_NUMCD
#endif
#ifndef CERNLIB_NUMCHK
#define CERNLIB_NUMCHK
#endif
