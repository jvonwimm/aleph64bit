*
* $Id: numnd1c.h,v 1.1.1.1 1996/02/15 17:48:38 mclareni Exp $
*
* $Log: numnd1c.h,v $
* Revision 1.1.1.1  1996/02/15 17:48:38  mclareni
* Kernlib
*
*
* This directory was created from kernnumt.car patch numnd1c
#ifndef CERNLIB_NUMND
#define CERNLIB_NUMND
#endif
#ifndef CERNLIB_NUMCHK
#define CERNLIB_NUMCHK
#endif
