*
* $Id: numuc1c.h,v 1.1.1.1 1996/02/15 17:48:38 mclareni Exp $
*
* $Log: numuc1c.h,v $
* Revision 1.1.1.1  1996/02/15 17:48:38  mclareni
* Kernlib
*
*
* This directory was created from kernnumt.car patch numuc1c
#ifndef CERNLIB_NUMUC
#define CERNLIB_NUMUC
#endif
#ifndef CERNLIB_NUMCHK
#define CERNLIB_NUMCHK
#endif
