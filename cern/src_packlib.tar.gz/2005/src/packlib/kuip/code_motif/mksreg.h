/*
 * $Id: mksreg.h,v 1.1.1.1 1996/03/08 15:33:12 mclareni Exp $
 *
 * $Log: mksreg.h,v $
 * Revision 1.1.1.1  1996/03/08 15:33:12  mclareni
 * Kuip
 *
 */
#ifndef _mksreg_
#define _mksreg_

/* global data */
extern SresRec       srec;             /* application resources */

#endif /* _mksreg_ */

